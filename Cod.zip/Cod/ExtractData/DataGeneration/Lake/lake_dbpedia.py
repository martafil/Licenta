import os.path
import sys

import rdflib
from rdflib.namespace import Namespace, RDFS

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import utils


def name_list(instances):
  g = rdflib.Graph()
  instance_list = []
  for instance in instances:
    g.load(instance)
    name = list(x for x in g.objects(instance, RDFS.label) if x.language == 'en')
    instance_list.append(str(name[0]))
  return instance_list


def get_countries(g, semweb, dbpedia):
  countries = list(x for x in g.objects(semweb, dbpedia['country']))
  return name_list(countries)


def get_abstract(g, semweb, dbpedia, language):
  abstracts = list(x for x in g.objects(semweb, dbpedia['abstract']) if x.language == language)
  # print (abstracts)
  return abstracts[0]


def get_lake_types(g, semweb, dbpedia):
  types = list(x for x in g.objects(semweb, dbpedia['type']))
  return name_list(types)


def get_info(lake_name):
  lake_name = lake_name.replace(" ", "_")
  g = rdflib.Graph()
  dbpedia = Namespace('http://dbpedia.org/ontology/')
  print(lake_name)

  url = ''.join(['http://dbpedia.org/resource/', lake_name])
  print(url)
  try:
    g.load(url)
    semweb = rdflib.URIRef(url)

    countries = get_countries(g, semweb, dbpedia)
    abstract = get_abstract(g, semweb, dbpedia, 'en')
    lake_type = get_lake_types(g, semweb, dbpedia)
  except:
    return {"abstract": "Sorry, but we do not have any information about this city yet."}
  return {
    "countries": countries,
    "abstract": utils.eliminate_nonascii_charactes(abstract),
    "type": lake_type
  }

# print(get_info("Lake Malawi"))
