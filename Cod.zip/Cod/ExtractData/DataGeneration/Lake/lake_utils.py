import pywikibot
import sys
import os.path

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import utils


def get_instance_name(instance):
  return utils.safe_get(instance, ["labels", "en"])


def get_instance_area(instance, wikidata_repo):
  instance = instance['claims']
  if 'P2046' in instance:
    unit = utils.safe_get(instance['P2046'][0].toJSON(), ["mainsnak", "datavalue", "value", "unit"])
    unit = utils.get_name_by_id(unit.split('/')[-1], wikidata_repo)
    amount = utils.safe_get(instance['P2046'][0].toJSON(), ["mainsnak", "datavalue", "value", "amount"])
    return {
      "amount": int(float(amount)),
      "unit": unit
    }
  return -1


def get_location(lake, wikidata, dbpedia, wikidata_repo):
  if wikidata in lake:
    results = lake[wikidata]
    country_ids = [
      utils.get_name_by_id('Q' + str(utils.safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])),
                     wikidata_repo)
      for x in results if (str(utils.safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])) != "")]
    return country_ids
  else:
    return []


def get_abstract(name):
  try:
    abstract = utils.basic_get_abstract(name)
  except:
    return None
  return utils.eliminate_nonascii_charactes(abstract)
