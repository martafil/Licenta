import pywikibot
import pywikibot.pagegenerators as pagegen
import lake_utils
import lake_dbpedia
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(os.path.join(os.path.dirname(__file__), '../City'))

import utils
import city_utils

def get_lake_list():
  with open('./requests/lake_wikidata.rq', 'r') as query_file:
    QUERY = query_file.read().replace('\n', '')

  wikidata = pywikibot.Site("wikidata", "wikidata")
  wikidata_repo = wikidata.data_repository()

  lake_list = list(pagegen.WikidataSPARQLPageGenerator(QUERY, site=wikidata, result_type=list))
  lake_info = []
  for x in lake_list:
    instance = x.get()
    name = lake_utils.get_instance_name(instance)
    country_id = city_utils.get_id_for_predicate(instance['claims'], 'P17', wikidata_repo)
    print(country_id)
    if (not utils.is_ascii(name)):
      name = ""
    location = lake_utils.get_location(instance['claims'], 'P17', 'dbo:country', wikidata_repo)
    info = lake_dbpedia.get_info(name)
    info.update({"wikidata": country_id})
    info.update({"area": lake_utils.get_instance_area(instance, wikidata_repo)})
    info.update({"name": name.lower().replace("lake", "").strip()})
    info.update({"official_name": name})
    info.update({"responses": city_utils.get_responses(str(x.id), wikidata_repo, wikidata, './Lake/responses.rq')})
    lake_info.append(info)
  lake_info = sorted(lake_info, key=lambda lake: (-1) * lake["area"]["amount"])
  for i in range(len(lake_info)):
    if (lake_info[i]["name"] != ""):
      lake_info[i].update({"place": str(i + 1)})
  lake_info = [lake for lake in lake_info if lake["name"] != "" and len(lake["wikidata"]) > 0]
  for i in range(len(lake_info)):
    lake_info[i].update({"id": str(i+1)})
  return lake_info

# get_lake_list()
