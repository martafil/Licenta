import city_utils
import os
import pywikibot
import pywikibot.pagegenerators as pagegen
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import utils


def get_city_list():
  global info
  with open('./requests/city_wikidata.rq', 'r') as query_file:
    QUERY = query_file.read().replace('\n', ' ')

  wikidata = pywikibot.Site("wikidata", "wikidata")
  wikidata_repo = wikidata.data_repository()

  city_list = list(pagegen.WikidataSPARQLPageGenerator(QUERY, site=wikidata))
  print(city_list)
  city_info = []
  for x in city_list:
    instance = x.get()
    name = city_utils.get_instance_name(instance)
    if (utils.is_ascii(name)):
      country_id = city_utils.get_id_for_predicate(instance['claims'], 'P17', wikidata_repo)[0]
      info = {}
      info.update({"population": city_utils.get_instance_population(instance)})
      info.update({"name": name})
      info.update({"official_name": name})
      info.update({"wikidata": country_id})
      info.update({"country": utils.get_name_by_id(country_id, wikidata_repo)})
      info.update({"water": city_utils.get_water(instance, wikidata_repo)})
      info.update({"capital": city_utils.is_capital(instance)})
      info.update({"altitude": city_utils.get_altitude(instance, wikidata_repo)})
      info.update({"abstract": city_utils.get_abstract(info["name"])})
      info.update({"responses": city_utils.get_responses((country_id, country_id, country_id) , wikidata_repo, wikidata, './City/responses.rq')})
      # print(info["name"])
      city_info.append(info)
      city_info = sorted(city_info, key=lambda lake: (-1) * lake["population"])
      for i in range(len(city_info)):
        city_info[i].update({"id":str(i + 1)})
  return city_info

