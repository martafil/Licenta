import sys
import os.path
import rdflib
from rdflib.namespace import Namespace

import pywikibot
import pywikibot.pagegenerators as pagegen

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import utils


def get_instance_name(instance):
  return utils.safe_get(instance, ["labels", "en"])


def get_instance_population(instance):
  return int(float(utils.safe_get(instance['claims']['P1082'][0].toJSON(), ["mainsnak", "datavalue", "value", "amount"])))

def get_id_for_predicate(city, predicate, wikidata_repo):
  if predicate in city:
    results = city[predicate]
    # print("\n\n\n")
    # print([str(utils.safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])) for x in results])
    # print("\n\n\n")
    return ['Q' + str(utils.safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])) 
            for x in results if (str(utils.safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])) != "")]
  else:
    return []

def get_location(city, predicate, wikidata_repo):
  if predicate in city:
    results = city[predicate]
    country_ids = get_id_for_predicate(city, predicate, wikidata_repo)
    # print("********\n", country_ids, "**********\n")
    country_name = [utils.get_name_by_id(instance_id, wikidata_repo) for instance_id in country_ids]
    return country_name[0]
  else:
    return []

def get_water(city, wikidata_repo):
  return utils.get_object_value_list_by_predicate(city, "P206", wikidata_repo)


def is_capital(city):
  return utils.is_instance_of(515, city)


def get_altitude(instance, wikidata_repo):
  instance = instance['claims']
  if 'P2044' in instance:
    unit = utils.safe_get(instance['P2044'][0].toJSON(), ["mainsnak", "datavalue", "value", "unit"])
    unit = utils.get_name_by_id(unit.split('/')[-1], wikidata_repo)
    amount = utils.safe_get(instance['P2044'][0].toJSON(), ["mainsnak", "datavalue", "value", "amount"])
    return {
      "amount": int(float(amount)),
      "unit": unit
    }
  return -1

def get_responses(ids, wikidata_repo, wikidata, path):
  with open(path, 'r') as query_file:
    QUERY = query_file.read().replace('\n', ' ')%ids
  print(QUERY)
  id_list = list(pagegen.WikidataSPARQLPageGenerator(QUERY, site=wikidata))
  names = [get_instance_name(x.get()) for x in id_list]
  return [y for y in names if len(y) > 0]

from SPARQLWrapper import SPARQLWrapper, JSON


def get_abstract(name):
  try:
    abstract = utils.basic_get_abstract(name)
  except:
    return None
  return utils.eliminate_nonascii_charactes(abstract)
