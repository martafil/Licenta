import pywikibot
import pywikibot.pagegenerators as pagegen
import os
import sys
import wikipedia

sys.path.append(os.path.join(os.path.dirname(__file__), '../City'))

import city_utils

wikipedia.set_lang("en")

def get_film_list():
  with open('./requests/film_wikidata.rq', 'r') as query_file:
    QUERY = query_file.read().replace('\n', ' ')

  wikidata = pywikibot.Site("wikidata", "wikidata")
  wikidata_repo = wikidata.data_repository()

  country_list = list(pagegen.WikidataSPARQLPageGenerator(QUERY, site=wikidata))
  print(country_list)
  film_info = []
  for x in country_list:
    instance = x.get()
    info = {}
    name = city_utils.get_instance_name(instance)
    info.update({"name": name})
    result = wikipedia.summary(name + " (film)", sentences=4)
    info.update({"question": result})
    
    film_info.append(info)
    for i in range(len(film_info)):
      film_info[i].update({"id": str(i + 1)})
  return film_info

# print((get_country_list()))

