import os
from SPARQLWrapper import SPARQLWrapper, JSON
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import utils


def get_area(instance):
  return utils.get_area(instance)


def get_continent(instance, wikidata_repo):
  return utils.get_object_value_by_predicare(instance, 'P30', wikidata_repo)


def get_neighbours(instance, wikidata_repo):
  return utils.get_object_value_list_by_predicate(instance, "P47", wikidata_repo)


def get_capital(instance, wikidata_repo):
  return utils.get_object_value_by_predicare(instance, 'P36', wikidata_repo)


def is_EU_member(instance):
  return utils.is_instance_of(185441, instance)


def is_NATO_member(instance):
  return utils.is_instance_of(595841, instance)

def get_abstract(name):
	try:
		abstract = utils.basic_get_abstract(name)
	except:
		print("*** EXEPT ***")
		with open('./requests/abstract_dbpedia.rq', 'r') as query_file:
			QUERY = query_file.read().replace('\n', ' ')
		sparql = SPARQLWrapper("http://dbpedia.org/sparql")
		sparql.setReturnFormat(JSON)

		sparql.setQuery(QUERY % name)  # the previous query as a literal string
		print(QUERY)
		try:
		  abstract = sparql.query().convert()["results"]["bindings"][0]["abstract"]["value"]
		except:
		  return None
	return utils.eliminate_nonascii_charactes(abstract)