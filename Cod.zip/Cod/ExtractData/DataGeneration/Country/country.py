import os
import country_utils
import pywikibot
import pywikibot.pagegenerators as pagegen
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), '../City'))

import city_utils


def get_country_list():
  global info
  with open('./requests/country_wikidata.rq', 'r') as query_file:
    QUERY = query_file.read().replace('\n', ' ')

  print(QUERY)
  wikidata = pywikibot.Site("wikidata", "wikidata")
  wikidata_repo = wikidata.data_repository()

  country_list = list(pagegen.WikidataSPARQLPageGenerator(QUERY, site=wikidata))
  country_info = []

  for x in country_list:
    instance = x.get()
    info = {}
    info.update({"wikidata": x.id})
    info.update({"name": city_utils.get_instance_name(instance)})
    info.update({"official_name": city_utils.get_instance_name(instance)})
    info.update({"area": country_utils.get_area(instance)})
    info.update({"water": city_utils.get_water(instance, wikidata_repo)})
    info.update({"continent": country_utils.get_continent(instance, wikidata_repo)})
    info.update({"neighbours": country_utils.get_neighbours(instance, wikidata_repo)})
    info.update({"capital": country_utils.get_capital(instance, wikidata_repo)})
    info.update({"EU": country_utils.is_EU_member(instance)})
    info.update({"NATO": country_utils.is_NATO_member(instance)})
    info.update({"responses": city_utils.get_responses((str(x.id), str(x.id)), wikidata_repo, wikidata, './Country/responses.rq')})
    abstract = country_utils.get_abstract(info["name"])
    # abstract = ""
    print(abstract)
    if abstract is not None:
      info.update({"abstract": abstract})
    country_info.append(info)
    country_info = sorted(country_info, key=lambda lake: (-1) * lake["area"])
    for i in range(len(country_info)):
      country_info[i].update({"id": str(i + 1)})
  return country_info

# print((get_country_list()))

