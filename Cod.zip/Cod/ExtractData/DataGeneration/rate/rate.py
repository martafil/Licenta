import os
from SPARQLWrapper import SPARQLWrapper, JSON
import pywikibot
import pywikibot.pagegenerators as pagegen
import sys

corespondece_master = {
	"Q49": 0.8, # America de Nord
	"Q48": 0.7, # Asia
	"Q46": 0.85, # Europa
	"Q18": 0.55, # America de sud
	"Q15": 0.5
	# altele 0.4
}

corespondece_beginner = {
	"Q49": 0.5, # America de Nord
	"Q48": 0.4, # Asia
	"Q46": 0.6, # Europa
	"Q18": 0.3, # America de sud
	"Q15": 0.25
	# altele 0.2
}

def get_country(id):
	with open('./rate/top.rq', 'r') as query_file:
		QUERY = query_file.read().replace('\n', ' ')
	wikidata = pywikibot.Site("wikidata", "wikidata")
	wikidata_repo = wikidata.data_repository()
	return list(pagegen.WikidataSPARQLPageGenerator(QUERY%id, site=wikidata, result_type=list))

def coef_position(i, n):
	poz = i/(n/3)
	if (poz == 0):
		return 0.9
	elif (poz == 1):
		return 0.8
	else:
		return 0.7

def get_result(countries, field_coef, corespondence, continent_id):
	# print("#########################")
	# print(field_coef)
	# print(corespondence[continent_id])
	# print(coef_position(0, len(countries)))
	# print("#########################")
	return {countries[i].id: field_coef * corespondence[continent_id] * coef_position(i, len(countries)) for i in range(len(countries))}


def compute(database_country, field_coef):
	# print("compute")
	global corespondece_master
	global corespondece_beginner

	res_master = {}
	res_beginner = {}
	for id in corespondece_master.keys():
		countries = get_country(id)
		res_master.update(get_result(countries, field_coef, corespondece_master, id))
		res_beginner.update(get_result(countries, field_coef, corespondece_beginner, id))
	return {
		"master": res_master,
		"beginner": res_beginner
	}
