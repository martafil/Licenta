import pywikibot
import rdflib
from rdflib.namespace import Namespace


def safe_get(json_object, keys):
  for key in keys:
    json_object = json_object.get(key)
    if json_object == None:
      return ""
  return json_object


def get_name_by_id(id, wikidata_repo):
  item = pywikibot.ItemPage(wikidata_repo, id)
  return item.get()['labels']['en']


def is_ascii(text):
  return all(ord(c) < 128 for c in text)


def eliminate_nonascii_charactes(text):
  import re
  sentences = re.split("\.|!|\?", text)
  final = ""
  count = 1
  for sentence in sentences:
    splited_sentence = re.split("\(|\)", sentence)
    sentence = "".join([splited_sentence[i] for i in range(len(splited_sentence)) if i % 2 == 0])
    if is_ascii(sentence):
      final += sentence + "."
      if (count == 4):
        break;
    count += 1
  return final


def get_area(instance):
  area_obj = safe_get(instance, ['claims', 'P2046'])
  if area_obj != "":
    return int(float(safe_get(area_obj[0].toJSON(), ["mainsnak", "datavalue", "value", "amount"])))
  return -1


def get_object_value_by_predicare(instance, predicate, wikidata_repo):
  instance = instance['claims']
  if predicate in instance:
    continent = instance[predicate]
    continent_id = safe_get(continent[0].toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])
    print(continent_id)
    return get_name_by_id("Q" + str(continent_id), wikidata_repo)
  return None

def get_object_value_list_by_predicate(instance, predicate, wikidata_repo):
  results = instance['claims']
  if predicate in results:
    results = results[predicate]
    values = [
      get_name_by_id('Q' + str(safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])), wikidata_repo)
      for x in results if (str(safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"])) != "")]
    return values
  return []


def is_instance_of(instance_type, instance):
  instance_of = [safe_get(x.toJSON(), ["mainsnak", "datavalue", "value", "numeric-id"]) for x in
                 instance["claims"]["P31"]]
  return instance_type in instance_of


def basic_get_abstract(name):
  name = name.replace(" ", "_")
  g = rdflib.Graph()
  dbpedia = Namespace('http://dbpedia.org/ontology/')
  url = ''.join(['http://dbpedia.org/resource/', name])
  g.load(url)
  semweb = rdflib.URIRef(url)
  abstract = list(x for x in g.objects(semweb, dbpedia['abstract']) if x.language == 'en')[0]
  return abstract
