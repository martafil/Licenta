import boto3
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), './City'))
sys.path.append(os.path.join(os.path.dirname(__file__), './Lake'))
sys.path.append(os.path.join(os.path.dirname(__file__), './Country'))

import lake


lakes = lake.get_lake_list();
g = open('./names/lake.txt', 'w')
for x in lakes:
	g.write(x["name"])
	g.write("\n")

# print("   aaa  ".strip())