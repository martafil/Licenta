import boto3
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), './City'))
sys.path.append(os.path.join(os.path.dirname(__file__), './Lake'))
sys.path.append(os.path.join(os.path.dirname(__file__), './Country'))
sys.path.append(os.path.join(os.path.dirname(__file__), './Film'))
sys.path.append(os.path.join(os.path.dirname(__file__), './rate'))

import country
import country_utils
import city
import lake
import film
import rate
from decimal import *

# Get the service resource.
dynamodb = boto3.resource('dynamodb')


def add_list(table_name, items, rate_coef):
	ratings = rate.compute(items, rate_coef)
	for country in items:
		print("country", country["wikidata"])
		if (country["wikidata"][0] in ratings["master"]):
			print ("in dict")
			country.update({"master": ratings["master"][country["wikidata"][0]]})
			country.update({"beginner": ratings["beginner"][country["wikidata"][0]]})
		else:
			print("not in dict")
			country.update({"master": rate_coef * 0.4})
			country.update({"beginner": rate_coef * 0.2})
		country["master"] = Decimal(str(country["master"]))
		country["beginner"] = Decimal(str(country["beginner"]))
		del country["wikidata"]
	print(country)

	table = dynamodb.Table(table_name)
	with table.batch_writer() as batch:
	  for i in range(len(items)):
	  	# print(items[i])
	    batch.put_item(
	      Item=items[i]
	    )	

# add_list("country", country.get_country_list(), 1)
# add_list("city", city.get_city_list(), 0.8)
add_list("lake", lake.get_lake_list(), 0.6)
# add_list("film", film.get_film_list())

# x = lake.get_lake_list()
# for y in x:
# 	print("***")
# 	print(y["name"], y["responses"])

# print(country_utils.get_abstract("Pakistan"))