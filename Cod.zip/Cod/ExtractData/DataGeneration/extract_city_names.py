import boto3
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), './City'))
sys.path.append(os.path.join(os.path.dirname(__file__), './Lake'))
sys.path.append(os.path.join(os.path.dirname(__file__), './Country'))

import city


cities = city.get_city_list();
g = open('./names/city.txt', 'w')
for x in cities:
	g.write(x["name"])
	g.write("\n")
