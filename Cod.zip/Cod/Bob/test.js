// function test(x) {
// 	x.nume = "ceva";
// }

// obj = {"nume": "x"}
// test(obj)
// console.log(obj	)

// var mc = require('./my_modules/add_multiple_choice')
// var data = {
// 	"Item": {
// 		"name": "test"
// 	}
// }
// var x = mc.add(data)
// console.log(x)
// console.log(data)
// var responses_order = [
// 	{
// 		"letter" : 'b'
// 	},
// 	{
// 		"letter" : 'c'
// 	},
// 	{
// 		"letter" : 'a'
// 	}
// ]
// responses_order.sort(function(a, b) {
// 		return a.letter > b.letter;
// 	})

// console.log(responses_order)

// var test = require('./my_modules/test')

// test.mood("None pretext",
// 		"ok",
// 	  	  {"attributes":{"sessionAttributes":{"test":{"table": { "ok_prob": 0.297,
//      "wrong_prob": 0.7030000000000001,
//      "ok": 
//       { "master_prob": 0.6363636363636364,
//         "beginner_prob": 0.36363636363636365,
//         "cond_en": 0.94566030460064 },
//      "wrong": 
//       { "master_prob": 0.4423897581792318,
//         "beginner_prob": 0.5576102418207681,
//         "cond_en": 0.9904022611439735 },
//      "entropy": 0.9771139000506035 },"posible":[], "left": 0, "correct": 1}}},
//      "user":{"userId":"cccc"}}, 				 
// 		  function(a, b) {console.log("**********"); console.log(a); console.log("**********");}
// 		 )

// test.handleTestBegin({"attributes":{"sessionAttributes":{}}}, 				 
// 		  function(a, b) { console.log(a["sessionAttributes"]["test"]);}
// 		 )

// var session = {
//     "sessionId": "SessionId.bb9f0b1e-d41d-4303-9bef-152a97f853f4",
//     "application": {
//       "applicationId": "amzn1.ask.skill.95e0051f-183b-4c52-97fc-2d34059bdc1c"
//     },
//     "attributes": {},
//     "user": {
//       "userId": "amzn1.ask.account.AED5UHHVQGDYFKD3YUCYLGIV2OPR3JRDYWU6J7LYXYT4CTGNLYTOKZN6FQZZ5IF3TIPJ3OFFTMV6MTZZLB6VCAD6QPNJBF3SECPGCRLKQOFO777FMGBQCP4QR4T3KKYKZ5EBR5UI6RTQGSM6HFATKCABWBGCIU375VO363AC3MPO5T5Z2IG56MSFVPDRQMS4QJO6TKOM733XEYY",
//       "accessToken": "719224353037164545-Pzoei2AubarZyuDDWx3XWB6E8J4ouQ0,RbDKxYUG9bL1NMUzAlYdZyn7JadRHQWeyl92URT3xR994"
//     },
//     "new": true
// }
// var twitter = require('./my_modules/my_twitter');
// twitter.post(session, function(a, b){console.log(b);}); 



function randomIntInc (low, high) {
    return Math.floor(Math.random() * (high - low + 1) + low);
}


function get_random_instance_id(st, dr) { // todo assure exists in db
  var solution = randomIntInc(st, dr);
  return solution.toString();
}

console.log(get_random_instance_id(0, 2))