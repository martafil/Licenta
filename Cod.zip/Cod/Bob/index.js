// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.

var AWS = require('aws-sdk');

var lake = require(__dirname + '/my_modules/lake.js');
var utils = require(__dirname + '/my_modules/utils.js');

exports.handler = function (event, context) {
    try {
        console.log("event.session.application.applicationId=" + event.session.application.applicationId);

        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */

    
        if (event.session.application.applicationId !== "amzn1.ask.skill.95e0051f-183b-4c52-97fc-2d34059bdc1c") {
            context.fail("Invalid Application ID");
        }

        if (event.session.new) {
            onSessionStarted({requestId: event.request.requestId}, event.session);
        }

        if (event.request.type === "LaunchRequest") {
            onLaunch(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(utils.buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "IntentRequest") {
            onIntent(
                event, 
                context,
                event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(utils.buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "SessionEndedRequest") {
            onSessionEnded(event.request, event.session);
            context.succeed();
        }else {
            utils.buildSpeechletResponseWithoutCard("error", "repromptText", false);
        }
    } catch (e) {
        context.fail("Exception: " + e);
    }
};

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session) {
    // add any session init logic here
}

function onLaunch(launchRequest, session, callback) {
    // handlePlaceIntent(session, callback);
    // handleTwitterPost(session, callback); 
    // console.log("*****");console.log(typeof(callback));
    // handleMovieIntent(session, callback);
    var twitter = require('./my_modules/my_twitter');
    twitter.post(session, callback); 
    // getWelcomeResponse(callback);
}

// onLaunch({}, {}, function(a, b) {console.log(a); console.log(b);})

function handleMoreInfo(session, callback) {
    if (session["attributes"]["sessionAttributes"]!==undefined &&
        session["attributes"]["sessionAttributes"]["MoreInfo"] !== undefined) {
        if (session["attributes"]["sessionAttributes"]["MoreInfo"] === true) {
            var speechOutput = session["attributes"]["sessionAttributes"]["Info"];
            var reprompt = "Choose other operation.";
            var header = "Bob answers!";
            var shouldEndSession = false;
            var sessionAttributes = {
                // "sessionAttributes": session["attributes"]["sessionAttributes"],
                "speechOutput" : speechOutput,
                "repromptText" : reprompt
            };
            callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
            return true;
        }
    } 
    return false;
}

function handleNewQuestion(session, callback) {
    // callback({}, utils.buildSpeechletResponse("header", session["attributes"]["sessionAttributes"]["newQuestion"], "reprompt", false));
    if (session["attributes"]["sessionAttributes"] !== undefined &&
        session["attributes"]["sessionAttributes"]["newQuestion"] === true) {
        ask_answer = require("./my_modules/ask_answer");
        ask_answer.handleRandomQuestion(session, callback);
        return true;
    } 
    return false;
}

function handleYesResponse(session, callback) {
    // if (handleMoreInfo(session, callback) == false && handleNewQuestion(session, callback) == false) {
    //     var speechOutput = "I did not asked you any question.";
    //     var reprompt = "Choose other operation.";
    //     var header = "Bob answers!";
    //     var shouldEndSession = false;
    //     var sessionAttributes = {
    //         "speechOutput" : speechOutput,
    //         "repromptText" : reprompt
    //     };
    //     callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
    // }   
    if (session["attributes"]["sessionAttributes"]!==undefined && (
        session["attributes"]["sessionAttributes"]["newQuestion"] !== undefined ||
        session["attributes"]["sessionAttributes"]["MoreInfo"] !== undefined)) {
        if (session["attributes"]["sessionAttributes"]["MoreInfo"] === true || 
            session["attributes"]["sessionAttributes"]["newQuestion"] === true) {
            var speechOutput = session["attributes"]["sessionAttributes"]["abstract"];
            var reprompt = "Choose other operation.";
            var header = "Bob answers!";
            var shouldEndSession = false;
            var sessionAttributes = {
                "speechOutput" : speechOutput,
                "repromptText" : reprompt
            };
            callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
        }
    } 
    var speechOutput = "I did not asked you any question.";
    var reprompt = "Choose other operation.";
    var header = "Bob answers!";
    var shouldEndSession = false;
    var sessionAttributes = {
        "speechOutput" : speechOutput,
        "repromptText" : reprompt
    };
    callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
}

function handleNoResponse(session, callback) {
    if (session["attributes"]["sessionAttributes"]!==undefined && (
        session["attributes"]["sessionAttributes"]["newQuestion"] !== undefined ||
        session["attributes"]["sessionAttributes"]["MoreInfo"] !== undefined)) {
        if (session["attributes"]["sessionAttributes"]["MoreInfo"] === true || 
            session["attributes"]["sessionAttributes"]["newQuestion"] === true) {
            var speechOutput = "Ok!";
            var reprompt = "Choose other operation.";
            var header = "Bob answers!";
            var shouldEndSession = false;
            var sessionAttributes = {
                "speechOutput" : speechOutput,
                "repromptText" : reprompt
            };
            callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
        }
    } 
    var speechOutput = "I did not asked you any question.";
    var reprompt = "Choose other operation.";
    var header = "Bob answers!";
    var shouldEndSession = false;
    var sessionAttributes = {
        "speechOutput" : speechOutput,
        "repromptText" : reprompt
    };
    callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
}

function handleMovieIntent(session, callback) {
    var ask_answer = require('./my_modules/ask_answer.js');
    var movie = require('./my_modules/movie.js');
    var ask_config = {
        table: "film",
        min: 1,
        max: 5,
        question: movie.construct_question_movie
    }
    console.log(typeof(callback))
    ask_answer.handleAskLake(ask_config, session, callback); 
}


function getAnswer(intent) {
    if (intent.slots.AnswerGB.value != undefined) {
        return intent.slots.AnswerGB;
    } if (intent.slots.AnswerLF.value != undefined) {
        return intent.slots.AnswerLF;
    } else if (intent.slots.AnswerC.value != undefined) {
        return intent.slots.AnswerC;
    } else if (intent.slots.AnswerM.value != undefined) {
        return intent.slots.AnswerM;
    } else if (intent.slots.AnswerLetter.value != undefined) {
        return intent.slots.AnswerLetter;
    }
}

function handlePlaceIntent(session, callback) {
    var place = require('./my_modules/place.js');
    place.get_player_place(session, callback, place.say_place)
}

function handleDoesNotKnow(session, callback) {
    var speechOutput = "Do you want a new question?"
    var reprompt = "If you want a new question please ask.";
    var header = "Bob handle does not know!";
    var shouldEndSession = false;
    var sessionAttributes = {
        "sessionAttributes": {
            "newQuestion": true
        },
        "speechOutput" : speechOutput,
        "repromptText" : reprompt
    };
   callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
}

function handleTwitterPost(session, callback) {
    console.log("handleTwitterPost");
    var place = require('./my_modules/place.js');
    place.get_player_place(session, callback, place.post_twitter)
}

/**
 * Called when the user specifies an intent for this skill.
 */
function onIntent(event, context, intentRequest, session, callback) {
    var intent = intentRequest.intent;
    var intentName = intentRequest.intent.name;
    var ask_answer = require('./my_modules/ask_answer.js');

    switch(intentName) {
        case "AMAZON.CancelIntent": handleFinishSessionRequest(intent, session, callback); break;
        case "AMAZON.StopIntent": handleFinishSessionRequest(intent, session, callback); break;
        case "AMAZON.YesIntent": handleYesResponse(session, callback); break;
        case "AMAZON.NoIntent": handleNoResponse(session, callback); break;
        case "BobAskLake": 
            session["attributes"] = {"sessionAttributes":{"test":{}}};
            var lake = require('./my_modules/lake');
            lake.handleLakeIntent(session, callback);
        break; 
        case "BobAskMovie": handleMovieIntent(session, callback); break;
        case "BobAskCity": 
            var city = require('./my_modules/city');
            session["attributes"] = {"sessionAttributes":{"test":{}}};
            city.handleCityIntent(session, callback); 
        break; 
        case "BobAskCountry": 
            var country = require('./my_modules/country');
            session["attributes"] = {"sessionAttributes":{"test":{}}};
            country.handleCountryIntent(session, callback); 
        break;
        case "BobAnswer":
        // callback({}, utils.buildSpeechletResponse("header", JSON.stringify(intent.slots), "reprompt", false));
            var answer = getAnswer(intent);
            ask_answer.handleAnswerLake(answer.value.toLowerCase(), session, callback); 
        break;
        case "BobPlace":
            handlePlaceIntent(session, callback);
        break;
        case "BobRandomQuestion": 
            ask_answer.handleRandomQuestion(session, callback); 
        break;
        case "BobBeginTest": 
            // callback({}, utils.buildSpeechletResponse("header", {}, "reprompt", false));
            var test = require('./my_modules/test');
            test.handleTestBegin(session, callback); 
        break;
        case "BobDoesnotKnow": handleDoesNotKnow(session, callback); break;
        case "BobPost":
            var twitter = require('./my_modules/my_twitter');
            twitter.post(session, callback); 
        break;
        default: handleFinishSessionRequest(intent, session, callback); break;
    } 
}

// var session = {
//     "sessionId": "SessionId.0ad6dab7-818c-4d20-b836-a97bf67ff600",
//     "application": {
//       "applicationId": "amzn1.ask.skill.95e0051f-183b-4c52-97fc-2d34059bdc1c"
//     },
//     "attributes": {
//       "speechOutput": "The city that you should guess is the largest city in Pakistan, but it is not its capital city. It has an population of 24300000 people. It is stuated at an altitude of 8 metre. So what city it is?",
//       "repromptText": "Tell me a city",
//       "sessionAttributes": {
//           "altitude": {
//             "amount": 8,
//             "unit": "metre"
//           },
//           "test": {
//             "left": 10,
//             "correct": 4
//           },
//           "id": "2",
//           "water": [],
//           "population": 24300000,
//           "capital": false,
//           "country": "Pakistan",
//           "name": ["Karachi", "a"],
//           "abstract": "Karachi  is the largest and most populous metropolitan city in the world and is also the capital of the province of Sindh It is the main seaport and financial center of Pakistan Karachi is also known as City of Lights mainly due to city's night life, for which it is famous as the city which never sleeps Karachi metro has an estimated population of over 235 million people as of 2013, and area of approximately 3,527 km2 , resulting in a density of more than 6,000 people per square kilometre  Karachi is the 7th largest urban agglomeration in the world, and the second largest in the Muslim world It is Pakistan's centre of banking, industry, economic activity and trade and is home to Pakistan's largest corporations, including those involved in textiles, shipping, automotive industry, entertainment, the arts, fashion, advertising, publishing, software development and medical research The city is a hub of higher education in South Asia and the Muslim world Karachi is also ranked as a beta world city It was the capital of Pakistan until Islamabad was constructed as a capital to spread development evenly across the country and to prevent it from being concentrated in Karachi Karachi is the location of the Port of Karachi and Port Bin Qasim, two of the region's largest and busiest ports After the independence of Pakistan, the city population increased dramatically when hundreds of thousands of Muslim Muhajirs from India and from other parts of South Asia came to settle in Karachi The city is located on the Arabian Sea coastline It is also known as the Uroos ul Bilaad \"The Bride of the Cities\" and the \"City of Lights\" and the \"City of the Quaid\", having been the birth and burial place of Quaid-e-Azam, the Great Leader, Muhammad Ali Jinnah, the founder of Pakistan, who made the city his home after Pakistan's independence from the British Raj on 14 August 1947 According to PricewaterhouseCoopers, In 2009 Karachi had a total GDP of $78 billion with conservative projections expecting it to rise to $193 billion in 2025"
//       }
//     },
//     "user": {
//       "userId": "amzn1.ask.account.AFGSMFSVK2CII33QWA4NVIOXHCHTXOTVH2SKTHVKU2UBDK4Z535RCKFBVE5OAXD5SDHYWJJB7XNMLS2VBUYWTYCV3AS2WXT6FLOCROJKNKDTKGXOCZ7NCTEQMPABFZ2QV34G5YYGCU36KUWIRYTVQ5DY3WUOMLE7ZKQCAFWAP6WCC4UQAVJKFFKYOTX4OHVYIZTK6YIHXLCAGXY",
//       "accessToken": "719224353037164545-Pzoei2AubarZyuDDWx3XWB6E8J4ouQ0,RbDKxYUG9bL1NMUzAlYdZyn7JadRHQWeyl92URT3xR994"
//     },
//     "new": false
//   };
//   var city = require('./my_modules/city.js');
//   var test = require('./my_modules/test.js');
//   var ask_answer = require('./my_modules/ask_answer.js'); 
//   ask_answer.handleAnswerLake("karachi", session, function(a, b){console.log(b);});
// city.handleCityIntent(session, function(a, b){console.log(b); process.exit()})
// test.handleTestBegin(session, function(a, b){console.log(b); process.exit()})
/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session) {

}

// ------- Skill specific logic -------

function getWelcomeResponse(callback) {
    var speechOutput = "Hello Bob is testing counting today!";

    var reprompt = "Do you wanna hear Bob count?";

    var header = "Bob Counts!";

    var shouldEndSession = false;

    var sessionAttributes = {
        "speechOutput" : speechOutput,
        "sessionAttributes": {"test": {}},
        "repromptText" : reprompt
    };

    callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
}

function handleGetHelpRequest(intent, session, callback) {
    // Ensure that session.attributes has been initialized
    if (!session.attributes) {
        session.attributes = {};
    }

}

function handleFinishSessionRequest(intent, session, callback) {
    // End the session with a "Good bye!" if the user wants to quit the game
    callback(session.attributes, utils.buildSpeechletResponseWithoutCard("Good bye!", "", true));
}










// var session = {
//   "session": {
//     "sessionId": "SessionId.fa45dc39-9d84-4434-b48e-be8f6bc89ffe",
//     "application": {
//       "applicationId": "amzn1.ask.skill.95e0051f-183b-4c52-97fc-2d34059bdc1c"
//     },
//     "attributes": {
//       "speechOutput": "The city that you should guess is the largest city in Democratic Republic of the Congo, but it is not its capital city. It has an population of 10125000 people. It is located next to body water of Congo cuenca. It is stuated at an altitude of 240 metre. So what city it is?",
//       "repromptText": "Tell me a city",
//       "sessionAttributes": {
//         "Item": {
//           "altitude": {
//             "amount": 240,
//             "unit": "metre"
//           },
//           "place": "8",
//           "water": [
//             "Congo cuenca"
//           ],
//           "population": 10125000,
//           "capital": false,
//           "country": "Democratic Republic of the Congo",
//           "name": "Kinshasa",
//           "abstract": " It is located on the Congo River Once a site of fishing villages, Kinshasa is now an urban area with a 2014 population of over 11 million It faces the capital of the neighbouring Republic of Congo, Brazzaville, which can be seen in the distance across the wide Congo River The city of Kinshasa is also one of the DRC's 11 provinces Because the administrative boundaries of the city-province cover a vast area, over 90% of the city-province's land is rural in nature, and the urban area only occupies a small section in the far western end of the city-province Kinshasa is the third largest urban area in Africa after Cairo and Lagos It is also the second largest \"francophone\" urban area in the world after Paris, French being the language of government, schools, newspapers, public services and high-end commerce in the city, while Lingala is used as a lingua franca in the street If current demographic trends continue, Kinshasa should surpass Paris in population around 2020 Kinshasa hosted the 14th Francophonie Summit in October 2012 Residents of Kinshasa are known as Kinois  or Kinshasans "
//         }
//       }
//     },
//     "user": {
//       "userId": "amzn1.ask.account.AFGSMFSVK2CII33QWA4NVIOXHCHTXOTVH2SKTHVKU2UBDK4Z535RCKFBVE5OAXD5SDHYWJJB7XNMLS2VBUYWTYCV3AS2WXT6FLOCROJKNKDTKGXOCZ7NCTEQMPABFZ2QV34G5YYGCU36KUWIRYTVQ5DY3WUOMLE7ZKQCAFWAP6WCC4UQAVJKFFKYOTX4OHVYIZTK6YIHXLCAGXY",
//       "accessToken": "719224353037164545-Pzoei2AubarZyuDDWx3XWB6E8J4ouQ0,RbDKxYUG9bL1NMUzAlYdZyn7JadRHQWeyl92URT3xR994"
//     },
//     "new": false
//   },
//   "request": {
//     "type": "IntentRequest",
//     "requestId": "EdwRequestId.912f6978-7c2c-45de-9849-3be250b9a900",
//     "locale": "en-US",
//     "timestamp": "2017-05-15T18:57:27Z",
//     "intent": {
//       "name": "BobAnswer",
//       "slots": {
//         "AnswerC": {
//           "name": "AnswerC"
//         },
//         "AnswerM": {
//           "name": "AnswerM"
//         },
//         "AnswerGB": {
//           "name": "AnswerGB",
//           "value": "Kinshasa"
//         },
//         "AnswerLF": {
//           "name": "AnswerLF"
//         }
//       }
//     }
//   },
//   "version": "1.0"
// };
// var event = {};
// var context = {};
// var answer = "Kinshasa";
// var intentRequest = {"intent": {"name":"BobAnswer", "slots": {"AnswerGB": {"value": answer}}}}
// var ask_answer = require('./my_modules/ask_answer.js');
// onIntent(event, context, intentRequest, session["session"], function(a, b){console.log(a); console.log(b);}); 
