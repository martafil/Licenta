function construct_question(data) {
	return data.question.replace(data.name, " the movie that you should guess ")
}

exports.construct_question_movie = construct_question;