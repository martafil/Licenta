function compute_answer_prob(object, master_prob, beginner_prob) {
    var ok_master = object.Item.master;
    var ok_beginner = object.Item.beginner;
    var res = {"ok_prob": 0, "wrong_prob": 0, "ok": {}, "wrong":{}}
    res.ok_prob = ok_master * master_prob + ok_beginner * beginner_prob;
    res.wrong_prob = (1 - ok_master) * master_prob + (1 - ok_beginner) * beginner_prob;
    return res;
}

exports.compute_table = function(object, P_z, enity_name, master_prob, beginner_prob) {
    P_z[enity_name] = compute_answer_prob(object, master_prob, beginner_prob);

    P_z[enity_name]["ok"]["master_prob"] = (object.Item.master * master_prob) / (object.Item.master * master_prob + object.Item.beginner * beginner_prob);
    P_z[enity_name]["ok"]["beginner_prob"] = (object.Item.beginner * beginner_prob) / (object.Item.master * master_prob + object.Item.beginner * beginner_prob);

    P_z[enity_name]["ok"]["cond_en"] = -1.0 / Math.log(2) * (P_z[enity_name]["ok"]["master_prob"] * Math.log(P_z[enity_name]["ok"]["master_prob"]) + P_z[enity_name]["ok"]["beginner_prob"] * Math.log(P_z[enity_name]["ok"]["beginner_prob"]));

    P_z[enity_name]["wrong"]["master_prob"] = ((1 - object.Item.master) * master_prob) / ((1 - object.Item.master) * master_prob + (1 - object.Item.beginner) * beginner_prob);
    P_z[enity_name]["wrong"]["beginner_prob"] = ((1 - object.Item.beginner) * beginner_prob) / ((1 - object.Item.master) * master_prob + (1 - object.Item.beginner) * beginner_prob);

    P_z[enity_name]["wrong"]["cond_en"] = -1.0 / Math.log(2) * (P_z[enity_name]["wrong"]["master_prob"] * Math.log(P_z[enity_name]["wrong"]["master_prob"]) + P_z[enity_name]["wrong"]["beginner_prob"] * Math.log(P_z[enity_name]["wrong"]["beginner_prob"]));

    P_z[enity_name]["entropy"] = P_z[enity_name].ok_prob * P_z[enity_name].ok.cond_en + P_z[enity_name].wrong_prob * P_z[enity_name].wrong.cond_en;
    // return P_z;
}