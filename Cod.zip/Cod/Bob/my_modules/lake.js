var question_helper = require("./question_helper.js")

function construct_bounded(data) { 
  if (data["countries"] !== undefined && data["countries"].length > 0) {
    return "It is bounded by " + question_helper.construct_list(data["countries"], false) + ". ";
  }
  return ""
}

function construct_area(data) {
  if (data["area"] != -1) {
    return "It has an area of " + data["area"]["amount"] + " km2. ";
  }
  return ""
}

function construct_type(data) { 
   if (data["type"] !== undefined && data["type"].length > 0) {
    return "And it is " + question_helper.construct_list(data["type"], true) + ". ";
  }
  return ""
}

function construct_question(data) {
  var top = "The lake you should guess is the <say-as interpret-as=\"ordinal\">"+ 
              data["place"] + "</say-as> largest lake in the world. ";
  var placement = construct_bounded(data);
  var area = construct_area(data);
  var type = construct_type(data);
  return top + placement + area + type + "So what lake it is? ";
}

function handleLakeIntentLocal(session, callback, pre_ask = "") {
    var ask_answer = require('./ask_answer.js');
    var ask_config = {
        table: "lake",
        min: 1,
        max: 5,
        question: construct_question
    }
    ask_answer.handleAskLake(ask_config, session, callback, pre_ask); 
}

exports.handleLakeIntent = handleLakeIntentLocal;
exports.construct_question_lake = construct_question;