function local_article(word) {
  var first_letter = word[0].toLowerCase();
  if (first_letter == 'a' || first_letter == 'e' || first_letter == 'i' || first_letter == 'o' || first_letter == 'u') {
    return "an";
  }
  return "a"
}

function construct_list_local(data, needs_article) {
  var result = ""
  if (data.length == 0) {
    return ""
  }
  if (data.length > 1) {
    for (var i = 1; i < data.length; ++i) {
      if (needs_article) {
        result += local_article(data[i]) + " "
      }
      result +=  data[i] + ", ";
    }
    result += "and "
  }
  if (needs_article) {
    result += local_article(data[0]) + " "
  }
  return result + data[0]
}

exports.article = local_article;
exports.construct_list = construct_list_local;