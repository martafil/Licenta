var utils = require('./utils.js');

exports.get_player_place = function(session, callback, not_error_action) {
    var database = require('./database.js');
    var utils = require('./utils.js');
    var id = session.user.userId;
    database.getFromDataBase(session, "usersPoints", "id", id, callback, function(data) {
        var params = {
            TableName: "usersPoints",
            FilterExpression: "points > :p", 
            ExpressionAttributeValues: {
                ":p": data.Item.points
            },
            Select: "COUNT"
        }
        var points = data.Item.points;
        var AWSregion = 'eu-west-1'; 
        var AWS = require('aws-sdk');
        AWS.config.update({region: AWSregion});
        var docClient = new AWS.DynamoDB.DocumentClient();
        docClient.scan(params, function(err, data) { 
            if (err) {
               database.handleErrorResponse(session, err, call);
            } else {
                not_error_action(session, callback, data, points);
            }
        });
    });
}

exports.say_place = function(session, callback, data, points) {
    var speechOutput = "You have " + points + " points. And you are the <say-as interpret-as=\"ordinal\">" + (data.Count + 1) + "</say-as> player.";
    var reprompt = "Tell me something...";
    var header = "Bob asks!";
    var shouldEndSession = false;
    var sessionAttributes = {
        "speechOutput" : speechOutput,
        "repromptText" : reprompt
    };
   callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
}

exports.post_twitter = function(session, callback, data, points) {
    var twitter = require("./my_twitter.js");
    // callback({}, utils.buildSpeechletResponse("", "test test", "", false));
    var database = require("./database.js");
    twitter.postTweet(session, data.Count + 1, points, callback)
    .timeout(3000)
    .then(function(data){
        var speechOutput = "I have posted on Twitter!";
        var reprompt = "Tell me something...";
        var header = "Bob is posting on Twitter!";
        var shouldEndSession = false;
        var sessionAttributes = {
            "speechOutput" : speechOutput,
            "repromptText" : reprompt
        };
       callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
    }).timeout(2000).catch(function(error) {
        console.log(error);
        database.handleErrorResponse(session, error, callback);
    });
}