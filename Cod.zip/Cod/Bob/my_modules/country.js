var question_helper = require("./question_helper.js")

function construct_border(data) {
	data = data.neighbours;
  if (data != undefined && data.length > 0)  {
    return "It shares the border with " + question_helper.construct_list(data, false) + ". "
  }
  return ""
}

function construct_population(data) {
  if (data.population !== undefined && data.population != -1) {
    return "It has an population of " + data.population + " people. ";
  }
  return ""
}

function construct_water(data) {
	data = data.water;
	if (data != undefined && data.length > 0)  {
		return "It is located next to body water of " + question_helper.construct_list(data, false) + ". "
	}
	return ""
}

function construct_NATO(data) {
  if (data.NOTO!= undefined && data.NATO) {
    return "It is a <say-as interpret-as=\"spell-out\">NATO</say-as> member. "
  }
  return "It is not a <say-as interpret-as=\"spell-out\">NATO</say-as> member. "
}

function construct_EU(data) {
  // console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%")
  // console.log(data)
  if (data.EU) {
    return "It is an European Union member. "
  }
  if (data.continent != undefined && data.continent.toLowerCase() == "europe") {
    return "It is not an European Union member. "
  }
  return ""
}


function construct_question(data) {
  // console.log("##########################");
  // console.log(data);
  // console.log("##########################");
  var top = "The country that you should guess is located in " + data.continent + ". ";
  var border = construct_border(data) 
  var water = construct_water(data);
  var population = construct_population(data);
  var EU = construct_EU(data);
  // var NATO = construct_NATO(data);
  return top + border + water + population + EU + "So what country it is? ";
}

function handleCountryIntentLocal(session, callback, pre_ask = "") {
    var ask_answer = require('./ask_answer.js');
    var ask_config = {
        table: "country",
        min: 1,
        max: 10,
        question: construct_question
    }
    ask_answer.handleAskLake(ask_config, session, callback, pre_ask); 
}

exports.construct_question_city = construct_question;
exports.handleCountryIntent = handleCountryIntentLocal;