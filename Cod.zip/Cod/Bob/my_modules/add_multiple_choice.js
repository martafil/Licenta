function shuffle(a) {
    for (let i = a.length; i; i--) {
        let j = Math.floor(Math.random() * i);
        [a[i - 1], a[j]] = [a[j], a[i - 1]];
    }
    return a
}

function get_random_order() {
	return shuffle([{'letter': 'a'}, 
					{'letter': 'b'}, 
					{'letter': 'c'}, 
					{'letter': 'd'}
					])
}


function next(choices, i, response) {
	++i;
	while (choices[i] == response) {
		++i;
	}
	return i;
}


exports.add = function(data) {
	responses_order = get_random_order()

	response = data["Item"]["name"];
	data["Item"]["name"] = [response, responses_order[0].letter]
	choices = shuffle(data["Item"]["responses"])

	responses_order[0]["name"] = data["Item"]["official_name"]
	var i = 0
	i = next(choices, i, response)
	responses_order[1]["name"] = choices[i]
	i = next(choices, i, response)
	responses_order[2]["name"] = choices[i]
	i = next(choices, i, response)
	responses_order[3]["name"] = choices[i]

	responses_order.sort(function(a, b) {
		return a.letter > b.letter;
	})

	return "The answer is a. " + responses_order[0].name + 
	       ". b. " + responses_order[1].name + 
	       ". c. " + responses_order[2].name + 
	       ". or d. " + responses_order[3].name + " .";
}	