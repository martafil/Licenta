function handleErrorResponseLocal(session, error, callback) {
  var utils = require("./utils.js")
  var speechOutput = "An internal error occured. Please come back later.\n" + JSON.stringify(error);
  var reprompt = "Please come back later.";
  var header = "Bob error.";
  var shouldEndSession = false;
  var sessionAttributes = {
    "speechOutput" : speechOutput,
    "sessionAttributes": session["sessionAttributes"],
    "repromptText" : reprompt
  };
  callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
}

exports.handleErrorResponse = handleErrorResponseLocal;

function randomIntInc (low, high) {
  return Math.floor(Math.random() * (high - low + 1) + low);
}

function getForTestLocal(pz, tables_list, pre_text, session, selectQuestion, callback) {
  var params = {
      "TableName": tables_list[pz].name,
      "Key": {"id": randomIntInc(1, tables_list[pz].max).toString()}
  };

  var AWS = require('aws-sdk');
  var AWSregion = 'eu-west-1'; 
  AWS.config.update({region: AWSregion});

  var docClient = new AWS.DynamoDB.DocumentClient();
  docClient.get(params, (err, data) => {
    if (err) {
      handleErrorResponseLocal(session, err, callback);
    } else {  
        // console.log(session);
        session["attributes"]["sessionAttributes"]["test"]["posible"].push(data);
        if (pz < 2) {
          getForTestLocal(pz + 1, tables_list, pre_text, session, selectQuestion, callback);
        }
        else {
          // console.log(typeof(selectQuestion))
          selectQuestion(pre_text, 
                         session["attributes"]["sessionAttributes"]["test"]["master_prob"], 
                         session["attributes"]["sessionAttributes"]["test"]["beginner_prob"],
                         session, 
                         callback); // ia din sesiune sau ceva
        }
      }
  });
}

exports.getForTest = getForTestLocal;

exports.getFromDataBase = function(session, databaseName, key_field, key_value, callback, onData){
  console.log("getFromDataBase begin")
  var AWSregion = 'eu-west-1'; 

  var params = {
      "TableName": databaseName,
      "Key": {}
  };
  params.Key[key_field] = key_value;
  console.log(params)

  var AWS = require('aws-sdk');
  AWS.config.update({region: AWSregion});

  var docClient = new AWS.DynamoDB.DocumentClient();
  console.log("before")
  docClient.get(params, (err, data) => {
    console.log("get done")
    if (err) {
      handleErrorResponseLocal(session, err, callback);
    } else {  
      onData(data);
    }
  });
  console.log("after")
}

exports.updatePoints = function(userId, session, callback, speechOutput, value) {
  var params = {
    TableName:"usersPoints",
    Key:{
        id: userId
    },
    UpdateExpression: "set points = points + :r",
    ExpressionAttributeValues:{
        ":r": value,
    },
    ReturnValues:"UPDATED_NEW"
  };

  var AWSregion = 'eu-west-1';
  var AWS = require('aws-sdk');
  AWS.config.update({region: AWSregion});
  var docClient = new AWS.DynamoDB.DocumentClient();

  var utils = require('./utils.js')

  docClient.update(params, function(err, data) {
    if (err) {
      handleErrorResponseLocal(session, err, callback)
    } else {
      var reprompt = "Tell me your answer.";
      var header = "Bob asks!";
      var shouldEndSession = false;
      var sessionAttributes = {
          "speechOutput" : speechOutput,
          "sessionAttributes" :{"test":{}},
          "repromptText" : reprompt
      };
      callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
    }
  });
}