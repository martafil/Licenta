var utils = require('./utils.js');


exports.during_test = function(session) {
	return session["attributes"]["sessionAttributes"]["test"] != undefined &&
           session["attributes"]["sessionAttributes"]["test"]["left"] != undefined
}

function construct_hints() {
    return [{"name": "lake", "max": 18}, 
            {"name": "country", "max": 20},
            {"name": "city", "max": 19}]
}

function compute_level_prob(prob_level, prob_ok) {
    return (prob_level * prob_ok) / (prob_level * prob_ok + (1 - prob_level) * prob_ok)
}


// console.log(compute_table([{"Item":{"master": 0.6, "beginner": 0.5}}], {"lake": {}}, "lake", 0, 0.33, 0.66))


function randomIntInc (low, high) {
    return Math.floor(Math.random() * (high - low + 1) + low);
}

function get_random_instance_id(st, dr) { // todo assure exists in db
  var solution = randomIntInc(st, dr);
  return solution.toString();
}

function selectQuestion(pre_text, master_prob, beginner_prob, session, callback) {
    var objects = session["attributes"]["sessionAttributes"]["test"]["posible"];
    delete session.attributes.sessionAttributes.test.posible;
    var P_z = {"lake": {}, "city": {}, "country": {}};
    
    var ml = require("./ml_utils");

    ml.compute_table(objects[0], P_z, "lake", master_prob, beginner_prob);
    ml.compute_table(objects[1], P_z, "country", master_prob, beginner_prob);
    ml.compute_table(objects[2], P_z, "city", master_prob, beginner_prob);

    var lake = require('./lake');
    var city = require('./city');
    var country = require('./country');
    var order = [{"table": "lake", "question": lake.construct_question_lake},
                 {"table": "country", "question": country.construct_question_city},
                 {"table": "city", "question": city.construct_question_city}]

    var mx = 0;
    for (i = 1; i < 3; ++i) {
        if (P_z[order[i].table]["entropy"] < P_z[order[mx].table]["entropy"]) {
            mx = i;
        }
    }

    session["attributes"]["sessionAttributes"]["test"]["table"] = P_z[order[mx].table];
    var ask = require('./ask_answer');
    ask.put_question(order[mx].table, order[mx].question, pre_text, objects[mx], session, callback);
}

exports.mood = function(pre_text, resp, session, callback, correct_update = 0) {
    console.log(session["attributes"]["sessionAttributes"]["test"]);
    session["attributes"]["sessionAttributes"]["test"]["master_prob"] = session["attributes"]["sessionAttributes"]["test"]["table"][resp]["master_prob"];
    session["attributes"]["sessionAttributes"]["test"]["beginner_prob"] = session["attributes"]["sessionAttributes"]["test"]["table"][resp]["beginner_prob"];
	--session["attributes"]["sessionAttributes"]["test"]["left"];
	session["attributes"]["sessionAttributes"]["test"]["correct"] += correct_update;

	speechOutput = pre_text + " ";
	if (session["attributes"]["sessionAttributes"]["test"]["left"] > 0) {
    	var database = require("./database")
        session["attributes"]["sessionAttributes"]["test"]["posible"] = [];
        database.getForTest(0, construct_hints(), pre_text, session, selectQuestion, callback);
    	// ask_answer.handleRandomQuestion(session, callback, speechOutput, 0); 
    } else {
        var value = 4;
        if (session["attributes"]["sessionAttributes"]["test"]["master_prob"] > 
            session["attributes"]["sessionAttributes"]["test"]["beginner_prob"]) {
            value =  10;
        }
        speechOutput += "You finished the test and scored " + value + " points.";
        var database = require('./database.js');
        database.updatePoints(session.user.userId, session, callback, speechOutput, value);
	}
}

exports.handleTestBegin = function(session, callback) {
    if (session["attributes"] == undefined) {
        session["attributes"] = {}
    }
    session["attributes"]["sessionAttributes"] = {};
    session["attributes"]["sessionAttributes"]["test"] = {};
    session["attributes"]["sessionAttributes"]["test"]["left"] = 3;
    session["attributes"]["sessionAttributes"]["test"]["correct"] = 0;
    session["attributes"]["sessionAttributes"]["test"]["entropy"] = 0;
    session["attributes"]["sessionAttributes"]["test"]["master_prob"] = 0.5;
    session["attributes"]["sessionAttributes"]["test"]["beginner_prob"] = 0.5;
    var ask_answer = require('./ask_answer');

	ask_answer.handleRandomQuestion(session, callback); 
}