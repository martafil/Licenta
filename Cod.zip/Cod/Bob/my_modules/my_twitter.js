var utils = require('./utils');

function getTweeterClient(session){
  var Twitter = require("twitter");
  console.log(session);  
  var access_token = session.user.accessToken.split(",");
  console.log(access_token)
  var client = new Twitter({
    consumer_key: 'PiPgj8LIEGxpb72UwLq7PYh4p',
    consumer_secret: 'NMoTmxrHXXmyAIBTGft0D3Q5sah0QZHhz0WBdKEULo3hRF4AUy',
    access_token_key: access_token[0],
    access_token_secret: access_token[1]
  });
  return client;
}

function postTweet(session, callback, place, points) {
  // callback({}, utils.buildSpeechletResponse("header", "ok", "reprompt", false));  
  var Promise = require("bluebird");
  return new Promise(function(resolve, reject) {
    var client = getTweeterClient(session);
    client.post('statuses/update', {status: "You have " + points + " points and you are on the " + place + " place. #Bob #Alexa #Licenta #UAIC"}, function(error, tweet, response) {
      if (!error) {
        console.log("Ceva fara eroare");
        resolve();
      }
      else {
        console.log("Ceva cu eroare eroare");
        reject(error);
       }
    });
  });
}

exports.post = function(session, callback) {
    var database = require('./database.js');
    var utils = require('./utils.js');
    var id = session.user.userId;
    database.getFromDataBase(session, "usersPoints", "id", id, callback, function(data) {
        var points = data.Item.points;
        var params = {
          TableName : "usersPoints",
          ProjectionExpression:"#yr",
          KeyConditionExpression: "#yr > :yyyy",
          ExpressionAttributeNames:{
              "#yr": "points"
          },
          ExpressionAttributeValues: {
              ":yyyy":points
          }
      };

        var AWSregion = 'eu-west-1';
        var AWS = require('aws-sdk');
        AWS.config.update({region: AWSregion});
        var docClient = new AWS.DynamoDB.DocumentClient();
        docClient.query(params, (err, data) => {
          if (!err) {
            database.handleErrorResponse(session, "My error is ugly", callback);
          } else {
            // callback({}, utils.buildSpeechletResponse("header", "error", "reprompt", true));
            var reprompt = "Use my skills.";
            var header = "Bob posts on Twitter!";
            var shouldEndSession = false;
            if (session["attributes"] == undefined) {
              session["attributes"] = {};
              session["attributes"]["sessionAttributes"] = {};
            }
            var sessionAttributes = {
                "sessionAttributes": session["attributes"]["sessionAttributes"],
                "repromptText" : reprompt
            };    
            var speechOutput = "";
            // callback({}, utils.buildSpeechletResponse("header", "place ", "reprompt", true));
            postTweet(session, callback, "" + 3, points).then(function() {
              speechOutput = "I have posted your score on Twitter!";
              // sessionAttributes["speechOutput"] = speechOutput;
              callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
            }).catch(function(error) {
              speechOutput = "An error has occurred. ";
              // sessionAttributes["speechOutput"] = speechOutput;
              callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
            });
          }
        });
    }); 
  }
