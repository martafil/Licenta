var utils = require('./utils.js');
var question_helper = require('./question_helper.js')

function randomIntInc (low, high) {
    return Math.floor(Math.random() * (high - low + 1) + low);
}


function get_random_instance_id(st, dr) { // todo assure exists in db
  var solution = randomIntInc(st, dr);
  return solution.toString();
}

function addTest(session) {
  // console.log(session)
  if (session["attributes"] == undefined) {
    session["attributes"] = {"sessionAttributes":{"test":{}}};
  } else if (session["attributes"]["sessionAttributes"] == undefined) {
    session["attributes"]["sessionAttributes"] = {"test":{}};
  } else if (session["attributes"]["sessionAttributes"]["test"] == undefined) {
    session["attributes"]["sessionAttributes"]["test"] = {};
  }
}

function put_question_local(topic, question_builder, pre_ask, object, session, callback) {
    // console.log("???????????????", session["attributes"]["sessionAttributes"])
    if (session["attributes"]["sessionAttributes"]["test"] != {} && session["attributes"]["sessionAttributes"]["test"]["table"] == undefined) {
      var P_z = {"ceva": {}};
      var ml = require("./ml_utils");
      ml.compute_table(object, P_z, "ceva", session["attributes"]["sessionAttributes"]["test"]["master_prob"], 
                                            session["attributes"]["sessionAttributes"]["test"]["beginner_prob"]);
      session["attributes"]["sessionAttributes"]["test"]["table"]  = P_z["ceva"];
    }
    var multiple_choice = require('./add_multiple_choice')
    console.log("function ", typeof(question_builder))
    var speechOutput = pre_ask + question_builder(object["Item"]) + multiple_choice.add(object);
    var question_helper = require('./question_helper')
    var reprompt = "Tell me " + question_helper.article(topic);
    var header = "Bob asks questions!";
    var shouldEndSession = false;
    var sessionAttributes = {
        "speechOutput" : speechOutput,
        "sessionAttributes": 
        {
          "test": session["attributes"]["sessionAttributes"]["test"],
          "name": object["Item"]["name"],
          "abstract": object["Item"]["abstract"]
        },
        "repromptText" : reprompt
    };
    callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
}

exports.put_question = put_question_local;

function handleAskLakeLocal(ask_config, session, callback, pre_ask = "") {
  addTest(session);
  var id = get_random_instance_id(ask_config["min"], ask_config["max"]);
  var database = require('./database');
  var multiple_choice = require('./add_multiple_choice');
  // callback({}, utils.buildSpeechletResponse("header", "oooo", "reprompt", false));
  database.getFromDataBase(session, ask_config.table, "id", id, callback, function(data) {
    // console.log("Dupa bd");
    console.log(session["attributes"]["sessionAttributes"]["test"])
    if (session["attributes"]["sessionAttributes"]["test"]["left"] == 6) {    
      var test = require('./test')
      var P_z = {"ceva":{}}
      var ml = require('./ml_utils')
      session["attributes"]["sessionAttributes"]["test"]["table"] = ml.compute_table(data, P_z, "ceva", 0.5, session["attributes"]["sessionAttributes"]["test"]["master_prob"], session["attributes"]["sessionAttributes"]["test"]["beginner_prob"]);
    }
    put_question_local(ask_config.table, ask_config.question, pre_ask, data, session, callback);
  });
}

exports.handleAskLake = handleAskLakeLocal;

function correct_response(session, answer) {
  return session["attributes"]["sessionAttributes"]["name"][0].toLowerCase() === answer.toLowerCase() ||
         session["attributes"]["sessionAttributes"]["name"][1].toLowerCase() === answer.toLowerCase();
}

function response_during_test(answer, session, callback) {
  var test  = require('./test');
  if (correct_response(session, answer)) {
      test.mood("You are right. ", "ok", session, callback, 1);
  } else {
    test.mood("You are wrong. ", "wrong", session, callback);
  }
}

function testAnswer(resp, session) {
  if (session["attributes"]["sessionAttributes"]["test"] != undefined &&
      session["attributes"]["sessionAttributes"]["test"] != {}) {
    session["attributes"]["sessionAttributes"]["test"]["master_prob"] = session["attributes"]["sessionAttributes"]["test"]["table"][resp]["master_prob"];
    session["attributes"]["sessionAttributes"]["test"]["beginner_prob"] = session["attributes"]["sessionAttributes"]["test"]["table"][resp]["beginner_prob"];
    session["attributes"]["sessionAttributes"]["test"]["entropy"] = session["attributes"]["sessionAttributes"]["test"]["table"]["entropy"];
  }
}

function handleAnswerLakeLocal(answer, session, callback) {
  if (session["attributes"]["sessionAttributes"]!==undefined &&
      session["attributes"]["sessionAttributes"]["name"] !== undefined) {
      var test  = require('./test');
      if (test.during_test(session)) {
         response_during_test(answer, session, callback);
      } else { 
        if (correct_response(session, answer)) {
            // testAnswer("ok", session);
            // var database = require('./database.js');
            // database.updatePoints(session.user.userId, session, callback);
            var speechOutput = "You guessed the answer!";
            if (session["attributes"]["sessionAttributes"]["abstract"] != undefined) {
              speechOutput += "Do you want to hear more about it?";
              session["attributes"]["sessionAttributes"]["MoreInfo"] = true;
            }
            var reprompt = "Tell me your answer.";
            var header = "Bob asks!";
            var shouldEndSession = false;
            var sessionAttributes = {
                "speechOutput" : speechOutput,
                "sessionAttributes" : session["attributes"]["sessionAttributes"],
                "repromptText" : reprompt
            };
            callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
        } else {
            // testAnswer("wrong", session["attributes"]["sessionAttributes"]["test"]);
            var speechOutput = "You are wrong. Please retry!";
            var reprompt = "Tell me your answer.";
            var header = "Bob asks!";
            var shouldEndSession = false;
            var sessionAttributes = {
                "speechOutput" : speechOutput,
                "sessionAttributes": session["attributes"]["sessionAttributes"],
                "repromptText" : reprompt
            };
            callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
        }
      }
  } else {
          var speechOutput = "Please repeat your answer.";
          var reprompt = "Use my skills.";
          var header = "Bob asks!";
          var shouldEndSession = false;
          var sessionAttributes = {
              "sessionAttributes": session["attributes"]["sessionAttributes"],
              "speechOutput" : speechOutput,
              "repromptText" : reprompt
          };    
          callback(sessionAttributes, utils.buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));
  }
}

exports.handleAnswerLake = handleAnswerLakeLocal;

function randomIntInc (low, high) {
    return Math.floor(Math.random() * (high - low + 1) + low);
}

exports.handleRandomQuestion = function(session, callback, pre_ask = "") {
    var lake = require("./lake");
    var country = require("./country");
    // callback({}, utils.buildSpeechletResponse("header", "here i am", "reprompt", false));
    var city = require("./city");
    var question = [city.handleCityIntent,  country.handleCountryIntent, lake.handleLakeIntent]
    var rand = randomIntInc(0, 2);
    // var rand = 0;
    // console.log("random",rand)
    // console.log(rand)
    // callback({}, utils.buildSpeechletResponse("header", {}, "reprompt", false));
    question[rand](session, callback, pre_ask);
}


