var question_helper = require("./question_helper.js")

function construct_capital(is_capital) {
	if (is_capital) {
		return ". And it is its capital city. "
	}
	return ", but it is not its capital city. "
}

function construct_population(data) {
  if (data.population !== undefined) {
    return "It has an population of " + data.population + " people. ";
  }
  return ""
}

function construct_water(data) {
	data = data.water;
	if (data != undefined && data.length > 0)  {
		return "It is located next to body water of " + question_helper.construct_list(data, false) + ". "
	}
	return ""
}

function construct_altitude(data) {
	if (data.altitude !== undefined && data.altitude != -1) {
		return "It is stuated at an altitude of " + data.altitude.amount + " " + data.altitude.unit + ". ";
  	}
  	return ""
}

function construct_question(data) {
  var top = "The city that you should guess is the largest city in " + data.country;
  var capital = construct_capital(data.capital) 
  var population = construct_population(data);
  var water = construct_water(data);
  var altitude = construct_altitude(data);
  return top + capital + population + water + altitude + "So what city it is?" ;
}

function handleCityIntentLocal(session, callback, pre_ask = "") {
  console.log("handleCityIntentLocal begin");
  var ask_answer= require('./ask_answer.js');
  var ask_config = {
      table: "city",
      min: 1,
      max: 10,
      question: construct_question
  }
  ask_answer.handleAskLake(ask_config, session, callback, pre_ask); 
}

exports.construct_question_city = construct_question;
exports.handleCityIntent = handleCityIntentLocal;